using demo.Data;
using demo.Models;
using System.Windows;

namespace demo.Windows.RequestWin
{
    public partial class AddRequest : Window
    {
        private DemoContext context;
        private readonly User currentUser;

        public AddRequest(User user)
        {
            InitializeComponent();
            context = new DemoContext();
            currentUser = user;
            BoxStatus.ItemsSource = context.Statuses.ToList();
            BoxPickupPoint.ItemsSource = context.PickupPoints.ToList();
        }

        private void Button_add(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(BoxDateDelivery.Text) &&
                !string.IsNullOrWhiteSpace(BoxDateOrder.Text) &&
                !string.IsNullOrWhiteSpace(BoxCode.Text) &&
                BoxPickupPoint.SelectedItem is PickupPoint pickupPoint &&
                BoxStatus.SelectedItem is Status status)
            {
                try
                {
                    Order order = new Order()
                    {
                        OrderDate = DateTime.Parse(BoxDateOrder.Text),
                        DeliveryDate = DateTime.Parse(BoxDateDelivery.Text),
                        Code = BoxCode.Text.Trim(),
                        PickupPointId = pickupPoint.Id,
                        StatusId = status.Id,
                        UserId = currentUser.Id
                    };

                    context.Orders.Add(order);
                    context.SaveChanges();
                    DialogResult = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Заполните все поля");
            }
        }

        private void Button_exit(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
