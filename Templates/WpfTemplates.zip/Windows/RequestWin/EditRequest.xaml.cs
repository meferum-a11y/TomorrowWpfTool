using demo.Data;
using demo.Models;
using Microsoft.EntityFrameworkCore;
using System.Windows;

namespace demo.Windows.RequestWin
{
    public partial class EditRequest : Window
    {
        private DemoContext context;
        private Order order;

        public EditRequest(Order selectedOrder)
        {
            InitializeComponent();
            context = new DemoContext();
            order = context.Orders
                .Include(q => q.PickupPoint)
                .Include(q => q.Status)
                .First(q => q.Id == selectedOrder.Id);

            PanelOrder.DataContext = order;
            BoxStatus.ItemsSource = context.Statuses.ToList();
            BoxStatus.SelectedItem = BoxStatus.Items.Cast<Status>().FirstOrDefault(q => q.Id == order.StatusId);
            BoxPickupPoint.ItemsSource = context.PickupPoints.ToList();
            BoxPickupPoint.SelectedItem = BoxPickupPoint.Items.Cast<PickupPoint>().FirstOrDefault(q => q.Id == order.PickupPointId);
        }

        private void Button_save(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(BoxDateDelivery.Text) &&
                !string.IsNullOrWhiteSpace(BoxDateOrder.Text) &&
                !string.IsNullOrWhiteSpace(BoxCode.Text) &&
                BoxPickupPoint.SelectedItem is PickupPoint pickupPoint &&
                BoxStatus.SelectedItem is Status status)
            {
                try
                {
                    order.OrderDate = DateTime.Parse(BoxDateOrder.Text);
                    order.DeliveryDate = DateTime.Parse(BoxDateDelivery.Text);
                    order.Code = BoxCode.Text.Trim();
                    order.PickupPointId = pickupPoint.Id;
                    order.StatusId = status.Id;

                    context.SaveChanges();
                    DialogResult = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Заполните все поля");
            }
        }

        private void Button_exit(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
