using demo.Data;
using demo.Models;
using Microsoft.EntityFrameworkCore;
using System.Windows;

namespace demo.Windows.RequestWin
{
    public partial class RequestWindows : Window
    {
        private DemoContext Context;
        private readonly User currentUser;

        public RequestWindows(User user)
        {
            InitializeComponent();
            Context = new DemoContext();
            currentUser = user;

            LoadOrders();

            if (user.RoleNavigation?.Role1 == "Администратор")
            {
                BoxOrder.MouseDoubleClick += BoxProduct_MouseDoubleClick;
                PanelBottomButton.Visibility = Visibility.Visible;
            }
            else
            {
                PanelBottomButton.Visibility = Visibility.Collapsed;
            }
        }

        private void LoadOrders()
        {
            Context.ChangeTracker.Clear();
            BoxOrder.ItemsSource = Context.Orders
                .Include(q => q.PickupPoint)
                .Include(q => q.Status)
                .Include(q => q.User)
                .ToList();
        }

        private void BoxProduct_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (BoxOrder.SelectedItem is not Order order)
            {
                return;
            }

            EditRequest edit = new EditRequest(order);
            if (edit.ShowDialog() == true)
            {
                LoadOrders();
            }
        }

        private void Button_add_reques(object sender, RoutedEventArgs e)
        {
            AddRequest add = new AddRequest(currentUser);
            if (add.ShowDialog() == true)
            {
                LoadOrders();
            }
        }

        private void Buutton_delite_reques(object sender, RoutedEventArgs e)
        {
            if (BoxOrder.SelectedItem is not Order order)
            {
                MessageBox.Show("Выберите заказ для удаления");
                return;
            }

            var orderDetails = Context.OrderArticles.Where(q => q.OrderId == order.Id).ToList();
            if (orderDetails.Any())
            {
                Context.OrderArticles.RemoveRange(orderDetails);
            }

            Context.Orders.Remove(order);
            Context.SaveChanges();
            LoadOrders();
        }

        private void Button_exit(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
