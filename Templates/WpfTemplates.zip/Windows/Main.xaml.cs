using demo.Data;
using demo.Models;
using demo.UserControllers;
using demo.Windows.Products;
using demo.Windows.RequestWin;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace demo.Windows
{
    public partial class Main : Window
    {
        private DemoContext context;
        private User? currentUser;
        private List<Product> products = new();
        private readonly string projPath = Path.GetDirectoryName(Assembly.GetEntryAssembly()?.Location) ?? AppContext.BaseDirectory;

        private string SortParam = "по возрастанию";
        private string SortFieldParam = "Количество";
        private string FiltParam = "Все диапазоны";

        public Main()
        {
            context = new DemoContext();
            InitializeComponent();
            BoxUserName.Text = "гость";
            PanelFind.Visibility = Visibility.Collapsed;
            PanelBottomButton.Visibility = Visibility.Collapsed;
            products = LoadProducts();
            DrawProductItem(products);
            DrawDiscountRanges();
        }

        public Main(User user)
        {
            context = new DemoContext();
            InitializeComponent();

            BoxUserName.Text = user.FullName;
            currentUser = user;

            products = LoadProducts();
            DrawProductItem(products);
            DrawDiscountRanges();
            ConfigureUserInterface(user);
        }

        private void ConfigureUserInterface(User user)
        {
            string role = user.RoleNavigation?.Role1 ?? string.Empty;

            PanelFind.Visibility = Visibility.Collapsed;
            PanelBottomButton.Visibility = Visibility.Collapsed;
            PanelBottomAdmin.Visibility = Visibility.Collapsed;
            PanelRequestBottom.Visibility = Visibility.Collapsed;

            if (role == "Администратор")
            {
                PanelFind.Visibility = Visibility.Visible;
                PanelBottomButton.Visibility = Visibility.Visible;
                PanelBottomAdmin.Visibility = Visibility.Visible;
                PanelRequestBottom.Visibility = Visibility.Visible;
                BoxProduct.MouseDoubleClick += BoxProduct_MouseDoubleClick;
            }
            else if (role == "Менеджер")
            {
                PanelFind.Visibility = Visibility.Visible;
                PanelBottomButton.Visibility = Visibility.Visible;
                PanelRequestBottom.Visibility = Visibility.Visible;
            }
        }

        private List<Product> LoadProducts()
        {
            context.ChangeTracker.Clear();
            return context.Products
                .Include(q => q.Supplier)
                .Include(q => q.Manufacturer)
                .Include(q => q.Category)
                .ToList();
        }

        public void DrawDiscountRanges()
        {
            ComboBoxItem.ItemsSource = new List<string>
            {
                "Все диапазоны",
                "0-10,99%",
                "11-14,99%",
                "15% и более"
            };
            ComboBoxItem.SelectedIndex = 0;
        }

        private void DrawProductItem(IEnumerable<Product>? productList)
        {
            if (BoxProduct == null)
            {
                return;
            }

            BoxProduct.Items.Clear();

            foreach (var item in productList ?? Enumerable.Empty<Product>())
            {
                if (item != null)
                {
                    ItemProduct xml = new ItemProduct(item);
                    BoxProduct.Items.Add(xml);
                }
            }
        }

        private void Button_exit_user(object sender, RoutedEventArgs e)
        {
            Authorization authorization = new Authorization();
            authorization.Show();
            this.Close();
        }

        private void BoxProduct_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (BoxProduct.SelectedItem is not ItemProduct controller || controller.DataContext is not Product product)
            {
                return;
            }

            EditProduct edit = new EditProduct(product);
            if (edit.ShowDialog() == true)
            {
                products = LoadProducts();
                Sort();
            }
        }

        private void Button_add_product(object sender, RoutedEventArgs e)
        {
            AddProduct add = new AddProduct();
            if (add.ShowDialog() == true)
            {
                products = LoadProducts();
                Sort();
            }
        }

        private void Button_request(object sender, RoutedEventArgs e)
        {
            string role = currentUser?.RoleNavigation?.Role1 ?? string.Empty;
            if (currentUser == null || role == "Авторизированный клиент")
            {
                MessageBox.Show("Заказы доступны только менеджеру и администратору");
                return;
            }

            RequestWindows request = new RequestWindows(currentUser);
            request.ShowDialog();
        }

        // Поиск
        private void BoxFind_TextChanged(object sender, TextChangedEventArgs e)
        {
            Sort();
        }

        // Выбор поля сортировки
        private void ComboSortField_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboSortField?.SelectedItem is ComboBoxItem selectedItem)
            {
                SortFieldParam = selectedItem.Content?.ToString() ?? "Количество";
            }
            Sort();
        }

        // Сортировка
        private void RadioUpp_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radio = sender as RadioButton;

            if (radio?.Content?.ToString() == "по возрастанию")
            {
                SortParam = "по возрастанию";
            }
            else if (radio?.Content?.ToString() == "по убыванию")
            {
                SortParam = "по убыванию";
            }
            Sort();
        }

        // Фильтрация по размеру скидки
        private void ComboSuppliers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ComboBoxItem.SelectedItem != null)
            {
                FiltParam = ComboBoxItem.SelectedItem.ToString() ?? "Все диапазоны";
            }
            Sort();
        }

        public void Sort()
        {
            if (BoxFind == null)
            {
                return;
            }

            string search = BoxFind.Text ?? string.Empty;

            products = LoadProducts()
                .Where(q => IsProductFound(q, search))
                .Where(IsProductInDiscountRange)
                .ToList();

            if (SortFieldParam == "Цена")
            {
                products = SortParam == "по убыванию"
                    ? products.OrderByDescending(q => q.Price ?? 0m).ToList()
                    : products.OrderBy(q => q.Price ?? 0m).ToList();
            }
            else
            {
                products = SortParam == "по убыванию"
                    ? products.OrderByDescending(q => q.Count ?? 0).ToList()
                    : products.OrderBy(q => q.Count ?? 0).ToList();
            }

            DrawProductItem(products);
        }

        private bool IsProductFound(Product product, string search)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return true;
            }

            return (product.Description?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false)
                || (product.Article?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false)
                || (product.Name?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false)
                || (product.Manufacturer?.Name?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false)
                || (product.Category?.Name?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false)
                || (product.Supplier?.Name?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false)
                || (product.Unit?.Contains(search, StringComparison.CurrentCultureIgnoreCase) ?? false);
        }

        private bool IsProductInDiscountRange(Product product)
        {
            int discount = product.Discount ?? 0;

            return FiltParam switch
            {
                "0-10,99%" => discount >= 0 && discount <= 10,
                "11-14,99%" => discount >= 11 && discount < 15,
                "15% и более" => discount >= 15,
                _ => true
            };
        }

        private void Buutton_delite_product(object sender, RoutedEventArgs e)
        {
            if (BoxProduct.SelectedItem is not ItemProduct controller || controller.DataContext is not Product prod)
            {
                MessageBox.Show("Выберите продукт для удаления");
                return;
            }

            var order = context.OrderArticles.FirstOrDefault(q => q.ProductId == prod.Id);
            if (order != null)
            {
                MessageBox.Show("Продукт не может быть удален, он участвует в заказе");
                return;
            }

            context.Products.Remove(prod);
            context.SaveChanges();
            products = LoadProducts();
            DrawProductItem(products);

            if (!string.IsNullOrWhiteSpace(prod.ImagePath))
            {
                string imagePath = Path.Combine(projPath, "Images", prod.ImagePath);
                if (File.Exists(imagePath))
                {
                    File.Delete(imagePath);
                }
            }
        }
    }
}
