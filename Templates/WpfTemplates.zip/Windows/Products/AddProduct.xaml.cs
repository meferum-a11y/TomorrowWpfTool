using demo.Data;
using demo.Models;
using Microsoft.Win32;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Media.Imaging;

namespace demo.Windows.Products
{
    public partial class AddProduct : Window
    {
        private readonly string projPath = Path.GetDirectoryName(Assembly.GetEntryAssembly()?.Location) ?? AppContext.BaseDirectory;
        private string? imageName = null;
        private BitmapImage selectImage;
        private DemoContext context;

        public AddProduct()
        {
            InitializeComponent();
            context = new DemoContext();

            selectImage = new BitmapImage(new Uri(Path.Combine(projPath, "Images", "Defaults", "picture.png")));
            BoxImage.Source = selectImage;
            BoxCategory.ItemsSource = context.Categories.ToList();
            BoxManufacturer.ItemsSource = context.Manufacturers.ToList();
            BoxSupplier.ItemsSource = context.Suppliers.ToList();
        }

        private void ButtonAddProduct(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(BoxArticle.Text) ||
                string.IsNullOrWhiteSpace(BoxDescription.Text) ||
                string.IsNullOrWhiteSpace(BoxDiscount.Text) ||
                string.IsNullOrWhiteSpace(BoxName.Text) ||
                string.IsNullOrWhiteSpace(BoxPrice.Text) ||
                string.IsNullOrWhiteSpace(BoxUnit.Text) ||
                string.IsNullOrWhiteSpace(BoxCount.Text) ||
                BoxCategory.SelectedItem is not Category category ||
                BoxManufacturer.SelectedItem is not Manufacturer manufacturer ||
                BoxSupplier.SelectedItem is not Supplier supplier)
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            try
            {
                Product newProduct = new Product()
                {
                    Article = BoxArticle.Text.Trim(),
                    Name = BoxName.Text.Trim(),
                    CategoryId = category.Id,
                    Description = BoxDescription.Text.Trim(),
                    ManufacturerId = manufacturer.Id,
                    SupplierId = supplier.Id,
                    Price = decimal.Parse(BoxPrice.Text, CultureInfo.CurrentCulture),
                    Unit = BoxUnit.Text.Trim(),
                    Count = int.Parse(BoxCount.Text),
                    Discount = int.Parse(BoxDiscount.Text),
                    ImagePath = imageName,
                };

                context.Products.Add(newProduct);
                context.SaveChanges();

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неверный формат ввода: {ex.Message}");
            }
        }

        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void ButtonLoadImage(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog()
            {
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*"
            };

            if (openFile.ShowDialog() == true)
            {
                Uri uri = new Uri(openFile.FileName);
                BitmapImage select = new(uri);

                if (select.Width > 400 || select.Height > 300)
                {
                    MessageBox.Show("Размеры изображения имеют неверный формат");
                    return;
                }

                string imagesDirectory = Path.Combine(projPath, "Images");
                Directory.CreateDirectory(imagesDirectory);
                imageName = openFile.SafeFileName;
                File.Copy(openFile.FileName, Path.Combine(imagesDirectory, imageName), true);

                selectImage = select;
                BoxImage.Source = selectImage;
            }
        }
    }
}
