using demo.Data;
using demo.Models;
using Microsoft.Win32;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Media.Imaging;

namespace demo.Windows.Products
{
    public partial class AddProduct : Window
    {
        private readonly string projPath = Path.GetDirectoryName(Assembly.GetEntryAssembly()?.Location) ?? AppContext.BaseDirectory;
        private string? imageName = null;
        private BitmapImage selectImage;
        private DemoContext context;

        public AddProduct()
        {
            InitializeComponent();
            context = new DemoContext();

            selectImage = new BitmapImage(new Uri(Path.Combine(projPath, "Images", "Defaults", "picture.png")));
            BoxImage.Source = selectImage;
            BoxCategory.ItemsSource = context.Categories.ToList();
            BoxManufacturer.ItemsSource = context.Manufacturers.ToList();
            BoxSupplier.ItemsSource = context.Suppliers.ToList();
        }

        private void ButtonAddProduct(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(BoxArticle.Text) ||
                string.IsNullOrWhiteSpace(BoxDescription.Text) ||
                string.IsNullOrWhiteSpace(BoxDiscount.Text) ||
                string.IsNullOrWhiteSpace(BoxName.Text) ||
                string.IsNullOrWhiteSpace(BoxPrice.Text) ||
                string.IsNullOrWhiteSpace(BoxUnit.Text) ||
                string.IsNullOrWhiteSpace(BoxCount.Text) ||
                BoxCategory.SelectedItem is not Category category ||
                BoxManufacturer.SelectedItem is not Manufacturer manufacturer ||
                BoxSupplier.SelectedItem is not Supplier supplier)
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            if (!decimal.TryParse(BoxPrice.Text, NumberStyles.Number, CultureInfo.CurrentCulture, out decimal price))
            {
                MessageBox.Show("Цена должна быть числом", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (price < 0)
            {
                MessageBox.Show("Цена не может быть отрицательной", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(BoxCount.Text, out int count))
            {
                MessageBox.Show("Количество на складе должно быть целым числом", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (count < 0)
            {
                MessageBox.Show("Количество на складе не может быть отрицательным", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(BoxDiscount.Text, out int discount))
            {
                MessageBox.Show("Скидка должна быть целым числом", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                Product newProduct = new Product()
                {
                    Article = BoxArticle.Text.Trim(),
                    Name = BoxName.Text.Trim(),
                    CategoryId = category.Id,
                    Description = BoxDescription.Text.Trim(),
                    ManufacturerId = manufacturer.Id,
                    SupplierId = supplier.Id,
                    Price = price,
                    Unit = BoxUnit.Text.Trim(),
                    Count = count,
                    Discount = discount,
                    ImagePath = imageName,
                };

                context.Products.Add(newProduct);
                context.SaveChanges();

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения товара: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void ButtonLoadImage(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog()
            {
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*"
            };

            if (openFile.ShowDialog() == true)
            {
                Uri uri = new Uri(openFile.FileName);
                BitmapImage select = new(uri);

                if (select.Width > 300 || select.Height > 200)
                {
                    MessageBox.Show("Размер изображения не должен превышать 300x200 пикселей", "Ошибка изображения", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string imagesDirectory = Path.Combine(projPath, "Images");
                Directory.CreateDirectory(imagesDirectory);
                imageName = openFile.SafeFileName;
                File.Copy(openFile.FileName, Path.Combine(imagesDirectory, imageName), true);

                selectImage = select;
                BoxImage.Source = selectImage;
            }
        }
    }
}
