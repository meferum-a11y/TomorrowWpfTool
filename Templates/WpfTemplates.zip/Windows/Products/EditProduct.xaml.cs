using demo.Data;
using demo.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Media.Imaging;

namespace demo.Windows.Products
{
    public partial class EditProduct : Window
    {
        private readonly string projPath = Path.GetDirectoryName(Assembly.GetEntryAssembly()?.Location) ?? AppContext.BaseDirectory;
        private DemoContext context;
        private Product product;
        private string? imageName = null;

        public EditProduct(Product selectedProduct)
        {
            InitializeComponent();
            context = new DemoContext();
            product = context.Products
                .Include(q => q.Category)
                .Include(q => q.Supplier)
                .Include(q => q.Manufacturer)
                .First(q => q.Id == selectedProduct.Id);
            Load();
        }

        private void Load()
        {
            BoxCategory.ItemsSource = context.Categories.ToList();
            BoxCategory.SelectedItem = BoxCategory.Items.Cast<Category>().FirstOrDefault(q => q.Id == product.CategoryId);

            BoxSupplier.ItemsSource = context.Suppliers.ToList();
            BoxSupplier.SelectedItem = BoxSupplier.Items.Cast<Supplier>().FirstOrDefault(q => q.Id == product.SupplierId);

            BoxManufacturer.ItemsSource = context.Manufacturers.ToList();
            BoxManufacturer.SelectedItem = BoxManufacturer.Items.Cast<Manufacturer>().FirstOrDefault(q => q.Id == product.ManufacturerId);

            BoxArticle.Text = product.Article;
            BoxName.Text = product.Name;
            BoxDescription.Text = product.Description;
            BoxDiscount.Text = product.Discount.ToString();
            BoxPrice.Text = product.Price?.ToString(CultureInfo.CurrentCulture);
            BoxUnit.Text = product.Unit;
            BoxCount.Text = product.Count.ToString();

            string imagePath = string.IsNullOrWhiteSpace(product.ImagePath)
                ? Path.Combine(projPath, "Images", "Defaults", "picture.png")
                : Path.Combine(projPath, "Images", product.ImagePath);

            if (File.Exists(imagePath))
            {
                BoxImage.Source = new BitmapImage(new Uri(imagePath));
            }
        }

        private void ButtonSaveProduct(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(BoxArticle.Text) ||
                string.IsNullOrWhiteSpace(BoxDescription.Text) ||
                string.IsNullOrWhiteSpace(BoxDiscount.Text) ||
                string.IsNullOrWhiteSpace(BoxName.Text) ||
                string.IsNullOrWhiteSpace(BoxPrice.Text) ||
                string.IsNullOrWhiteSpace(BoxUnit.Text) ||
                string.IsNullOrWhiteSpace(BoxCount.Text) ||
                BoxCategory.SelectedItem is not Category category ||
                BoxManufacturer.SelectedItem is not Manufacturer manufacturer ||
                BoxSupplier.SelectedItem is not Supplier supplier)
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            try
            {
                product.Article = BoxArticle.Text.Trim();
                product.Name = BoxName.Text.Trim();
                product.CategoryId = category.Id;
                product.Description = BoxDescription.Text.Trim();
                product.ManufacturerId = manufacturer.Id;
                product.SupplierId = supplier.Id;
                product.Price = decimal.Parse(BoxPrice.Text, CultureInfo.CurrentCulture);
                product.Unit = BoxUnit.Text.Trim();
                product.Count = int.Parse(BoxCount.Text);
                product.Discount = int.Parse(BoxDiscount.Text);

                if (imageName != null)
                {
                    product.ImagePath = imageName;
                }

                context.SaveChanges();
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неверный формат ввода: {ex.Message}");
            }
        }

        private void ButtonExit(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void ButtonLoadImage(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog()
            {
                Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*"
            };

            if (openFile.ShowDialog() == true)
            {
                Uri uri = new Uri(openFile.FileName);
                BitmapImage select = new(uri);

                if (select.Width > 400 || select.Height > 300)
                {
                    MessageBox.Show("Размеры изображения имеют неверный формат");
                    return;
                }

                string imagesDirectory = Path.Combine(projPath, "Images");
                Directory.CreateDirectory(imagesDirectory);
                imageName = openFile.SafeFileName;
                File.Copy(openFile.FileName, Path.Combine(imagesDirectory, imageName), true);

                BoxImage.Source = select;
            }
        }
    }
}
