using demo.Models;
using System.IO;
using System.Reflection;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace demo.UserControllers
{
    public partial class ItemProduct : UserControl
    {
        private string projPath = Path.GetDirectoryName(Assembly.GetEntryAssembly()?.Location) ?? AppContext.BaseDirectory;

        public ItemProduct(Product product)
        {
            InitializeComponent();
            DataContext = product;

            string path = string.IsNullOrWhiteSpace(product.ImagePath)
                ? Path.Combine(projPath, "Images", "Defaults", "picture.png")
                : Path.Combine(projPath, "Images", product.ImagePath);

            try
            {
                BitmapImage bitmap = new(new Uri(path));
                BoxImage.Source = bitmap;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                BitmapImage bitmap = new(new Uri(Path.Combine(projPath, "Images", "Defaults", "picture.png")));
                BoxImage.Source = bitmap;
            }

            int discount = product.Discount ?? 0;
            decimal price = product.Price ?? 0m;

            if (discount > 15)
            {
                BoxDiscount.Background = new BrushConverter().ConvertFrom("#008080") as SolidColorBrush;
            }

            if (discount > 0)
            {
                BoxPrice.Foreground = Brushes.Red;
                BoxPrice.TextDecorations.Add(System.Windows.TextDecorations.Strikethrough);
                BoxNewPrice.Text = (price * (1 - discount / 100m)).ToString("0.##");
                BoxNewPrice.Foreground = Brushes.Black;
            }

            if ((product.Count ?? 0) == 0)
            {
                RootPanel.Background = Brushes.LightGray;
                BoxDiscount.Background = Brushes.LightGray;
            }
        }
    }
}
